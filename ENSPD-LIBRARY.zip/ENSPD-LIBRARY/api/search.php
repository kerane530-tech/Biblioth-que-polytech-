<?php
// Replace the top require_once blocks in both files with:
define('APP_RUNNING', true);
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
initSession();
require_once __DIR__ . '/../includes/functions.php';
I18n::init();

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed.']);
    exit;
}

$query = trim($_GET['q'] ?? '');
if (empty($query)) {
    echo json_encode(['success' => false, 'message' => 'Please enter a search term.', 'papers' => [], 'total' => 0]);
    exit;
}

try {
    $search = buildSearchQuery($query);
    $conditions = ["p.status = 'approved'", "({$search['conditions']})"];
    $params = $search['params'];
    
    // Apply filters
    if (!empty($_GET['file_type'])) {
        $conditions[] = 'p.file_type = ?';
        $params[] = $_GET['file_type'];
    }
    if (!empty($_GET['exam_level'])) {
        $conditions[] = 'p.exam_level = ?';
        $params[] = $_GET['exam_level'];
    }
    if (!empty($_GET['difficulty'])) {
        $conditions[] = 'p.difficulty = ?';
        $params[] = $_GET['difficulty'];
    }
    if (!empty($_GET['download_min'])) {
        $min = (int)$_GET['download_min'];
        $conditions[] = 'p.download_count >= ?';
        $params[] = $min;
    }
    if (!empty($_GET['date_range'])) {
        $ranges = ['week' => 7, 'month' => 30, 'year' => 365];
        if (isset($ranges[$_GET['date_range']])) {
            $conditions[] = 'p.created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)';
            $params[] = $ranges[$_GET['date_range']];
        }
    }
    
    $whereSQL = implode(' AND ', $conditions);
    
    $papers = dbFetchAll(
        "SELECT p.id, p.title, p.authors, p.abstract, p.keywords,
         p.publication_year, p.file_type, p.file_size,
         p.download_count, p.view_count, p.created_at,
         s.name AS subject_name, s.slug AS subject_slug, s.icon AS subject_icon,
         u.username AS uploader_name
         FROM papers p
         JOIN subjects s ON p.subject_id = s.id
         JOIN users u ON p.uploaded_by = u.id
         WHERE {$whereSQL}
         ORDER BY p.download_count DESC, p.created_at DESC
         LIMIT 20",
        $params
    );
    
    echo json_encode(['success' => true, 'papers' => $papers, 'total' => count($papers), 'query' => $query], JSON_UNESCAPED_UNICODE);
} catch (Exception $e) {
    error_log('Search API error: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred.', 'papers' => [], 'total' => 0]);
}
