<?php
/**
 * ============================================================
 * Download API Endpoint (api/download.php)
 * ============================================================
 * 
 * Handles paper file downloads with:
 * - Paper existence validation
 * - Download count tracking
 * - Download history logging
 * - File streaming with proper headers
 * - Security checks to prevent directory traversal
 * 
 * Request: GET /api/download.php?id=NNN
 * Response: File download with appropriate headers, or redirect
 * ============================================================
 */

// Initialize the application
// Replace the top require_once blocks in both files with:
define('APP_RUNNING', true);
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
initSession();
require_once __DIR__ . '/../includes/functions.php';

// Get paper ID
$paperId = (int)($_GET['id'] ?? 0);

// Validate paper ID
if ($paperId <= 0) {
    setFlash('error', 'Invalid paper ID.');
    header('Location: ' . APP_URL . '/pages/browse.php');
    exit;
}

// Fetch paper record
$paper = dbFetchOne(
    "SELECT id, file_path, file_name, file_type, file_size, title, status
     FROM papers WHERE id = ?",
    [$paperId]
);

// Validate paper exists and is approved
if (!$paper || $paper['status'] !== 'approved') {
    setFlash('error', 'Paper not found or not available for download.');
    header('Location: ' . APP_URL . '/pages/browse.php');
    exit;
}

// Build the full file path
$filePath = UPLOAD_DIR . $paper['file_path'];

// Security: Check if file exists and is actually a file (not directory)
if (!file_exists($filePath) || !is_file($filePath)) {
    // For demo purposes, create a placeholder file if none exists
    // In production, this should show an error
    $demoContent = "Research Paper: " . $paper['title'] . "\n\n";
    $demoContent .= "This is a demo placeholder file.\n";
    $demoContent .= "In a production environment, the actual PDF/document would be here.\n\n";
    $demoContent .= "File: " . $paper['file_name'] . "\n";
    $demoContent .= "Type: " . strtoupper($paper['file_type']) . "\n";
    $demoContent .= "Size: " . formatFileSize($paper['file_size']) . "\n";
    
    // Create uploads directory if it doesn't exist
    if (!is_dir(UPLOAD_DIR)) {
        mkdir(UPLOAD_DIR, 0755, true);
    }
    
    // Write demo file
    file_put_contents($filePath, $demoContent);
}

// Security: Verify the resolved path is within the uploads directory
$realUploadDir = realpath(UPLOAD_DIR);
$realFilePath = realpath($filePath);

if ($realFilePath === false || strpos($realFilePath, $realUploadDir) !== 0) {
    http_response_code(403);
    exit('Access denied.');
}

// Record the download
$userId = $_SESSION['user_id'] ?? null;
recordDownload($paperId, $userId);

// Determine MIME type based on file extension
$mimeTypes = [
    'pdf'  => 'application/pdf',
    'doc'  => 'application/msword',
    'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'txt'  => 'text/plain',
    'rtf'  => 'application/rtf',
];

$mimeType = $mimeTypes[$paper['file_type']] ?? 'application/octet-stream';

// Set download headers
header('Content-Type: ' . $mimeType);
header('Content-Disposition: attachment; filename="' . $paper['file_name'] . '"');
header('Content-Length: ' . filesize($filePath));
header('Content-Transfer-Encoding: binary');
header('Cache-Control: no-cache, must-revalidate');
header('Pragma: public');
header('Expires: 0');

// Clear any output buffers to prevent corruption
if (ob_get_level()) {
    ob_end_clean();
}

// Stream the file to the client
readfile($filePath);
exit;
