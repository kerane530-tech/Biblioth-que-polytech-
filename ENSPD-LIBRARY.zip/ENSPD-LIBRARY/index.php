<?php
require_once __DIR__ . '/includes/bootstrap.php';
$pageTitle = t('ENSPD-LIBRARY');
$activePage = 'home';

$totalPapers = dbFetchOne("SELECT COUNT(*) as count FROM papers WHERE status = 'approved'");
$totalSubjects = dbFetchOne("SELECT COUNT(*) as count FROM subjects");
$totalUsers = dbFetchOne("SELECT COUNT(*) as count FROM users WHERE is_active = 1");
$totalDownloads = dbFetchOne("SELECT COALESCE(SUM(download_count), 0) as count FROM papers");

$featuredPapers = dbFetchAll(
    "SELECT p.*, s.name AS subject_name, s.slug AS subject_slug, s.icon AS subject_icon,
     u.username AS uploader_name
     FROM papers p
     JOIN subjects s ON p.subject_id = s.id
     JOIN users u ON p.uploaded_by = u.id
     WHERE p.is_featured = 1 AND p.status = 'approved'
     ORDER BY p.created_at DESC LIMIT 6"
);

$subjects = getSubjects();
require_once __DIR__ . '/includes/header.php';
?>

<section class="hero">
<div class="container hero-content">
    <h1><?= t('ENSPD-LIBRARY') ?></h1>
    <p class="hero-subtitle"><?= t('Bibliothèque Numérique de l\' École Nationale Supérieure Polytechnique de Douala') ?></p>
    
    <div class="search-section">
        <form id="searchForm" class="search-bar" action="pages/browse.php" method="GET">
            <input type="text" id="searchInput" name="q" placeholder="<?= t('Rechercher un document...') ?>" autocomplete="off" aria-label="Search">
            <button type="submit" class="btn btn-primary">🔍 <?= t('Rechercher') ?></button>
        </form>
        
        <button class="filters-toggle" id="filtersToggle">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>
            <?= t('Filtres avancés') ?>
        </button>
        <section class="formations">

    <div class="container">

        <h2>Nos Filières</h2>

        <div class="academic-grid">

            <div class="academic-card">
                <h3>Génie Informatique</h3>
                <p>
                    Développement Web, Réseaux,
                    Intelligence Artificielle,
                    Bases de données
                </p>
            </div>

            <div class="academic-card">
                <h3>Génie Civil</h3>
                <p>
                    Structures, BTP,
                    Hydraulique, Topographie
                </p>
            </div>

            <div class="academic-card">
                <h3>Génie Électrique</h3>
                <p>
                    Électronique,
                    Automatisme,
                    Énergie
                </p>
            </div>

            <div class="academic-card">
                <h3>Génie Mécanique</h3>
                <p>
                    CAO,
                    Thermodynamique,
                    Fabrication
                </p>
            </div>

        </div>

    </div>

</section>

        
        <div class="advanced-filters" id="advancedFilters">
            <div class="filters-grid">
                <div class="filter-group">
                    <label><?= t('filter.file_type') ?></label>
                    <select id="filterFileType">
                        <option value=""><?= t('filter.all_types') ?></option>
                        <option value="pdf">PDF</option>
                        <option value="docx">DOCX</option>
                        <option value="txt">TXT</option>
                        <option value="rtf">RTF</option>                    </select>
                </div>
                <div class="filter-group">
                    <label><?= t('filter.upload_date') ?></label>
                    <select id="filterDateRange">
                        <option value=""><?= t('filter.any_time') ?></option>
                        <option value="week"><?= t('filter.last_week') ?></option>
                        <option value="month"><?= t('filter.last_month') ?></option>
                        <option value="year"><?= t('filter.last_year') ?></option>
                    </select>
                </div>
                <div class="filter-group">
                    <label><?= t('filter.download_count') ?></label>
                    <select id="filterDownloads">
                        <option value=""><?= t('filter.any_count') ?></option>
                        <option value="100"><?= t('filter.popular') ?></option>
                        <option value="500"><?= t('filter.very_popular') ?></option>
                    </select>
                </div>
                <div class="filter-group">
                    <label><?= t('filter.exam_level') ?></label>
                    <select id="filterExamLevel">
                        <option value=""><?= t('filter.all_levels') ?></option>
                        <option value="O-Level">O-Level</option>
                        <option value="A-Level">A-Level</option>
                        <option value="University">University</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label><?= t('filter.difficulty') ?></label>
                    <select id="filterDifficulty">
                        <option value=""><?= t('filter.all_difficulty') ?></option>
                        <option value="Easy">Easy</option>
                        <option value="Medium">Medium</option>
                        <option value="Hard">Hard</option>
                    </select>
                </div>
            </div>
            <div class="filters-actions">
                <button class="btn btn-ghost btn-sm" onclick="clearFilters()"><?= t('filter.clear') ?></button>
                <button class="btn btn-primary btn-sm" id="applyFilters"><?= t('filter.apply') ?></button>
            </div>
        </div>
        
        <div class="search-tags">
            <a href="pages/browse.php?subject=mathématiques" class="search-tag" data-subject="Mathématiques"> Mathématiques</a>
            <a href="pages/browse.php?subject=physique" class="search-tag" data-subject="Physique"> Physique</a>
            <a href="pages/browse.php?subject=économie" class="search-tag" data-subject="économie"> économie</a>
            <a href="pages/browse.php?subject=génie-mécanique" class="search-tag" data-subject="Génie-Mécanique"> Génie-Mécanique</a>
            <a href="pages/browse.php?subject=génie-Industriel" class="search-tag" data-subject="Génie-Industriel"> Génie-Industriel</a>
            <a href="pages/browse.php?subject=génie-civil" class="search-tag" data-subject="Génie-Civil"> Génie-Civil</a>
            <a href="pages/browse.php?subject=génie-Informatique" class="search-tag" data-subject="Génie-Informatique"> Génie-Informatique</a>        </div>
    </div>
    
    <div id="searchResults" class="search-results-container"></div>
</div>
</section>

<section class="stats-section">
<div class="container">
    <div class="stats-grid">
        <div class="stat-item"><span class="stat-number"><?= number_format($totalPapers['count'] ?? 0) ?></span><span class="stat-label"><?= t('stats.papers') ?></span></div>
        <div class="stat-item"><span class="stat-number"><?= number_format($totalSubjects['count'] ?? 0) ?></span><span class="stat-label"><?= t('stats.subjects') ?></span></div>
        <div class="stat-item"><span class="stat-number"><?= number_format($totalUsers['count'] ?? 0) ?></span><span class="stat-label"><?= t('stats.users') ?></span></div>
        <div class="stat-item"><span class="stat-number"><?= number_format($totalDownloads['count'] ?? 0) ?></span><span class="stat-label"><?= t('stats.downloads') ?></span></div>
    </div>
</div>
</section>

<section class="subjects-section">
<div class="container">
    <div class="section-header">
        <h2><?= t('subjects.title') ?></h2>
        <p><?= t('subjects.subtitle') ?></p>
    </div>
    <div class="grid grid-3" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:1.5rem;">
        <?php foreach ($subjects as $subject): ?>
        <a href="pages/browse.php?subject=<?= sanitize($subject['slug']) ?>" class="subject-card">
            <span class="subject-icon"><?= sanitize($subject['icon'] ?? '📄') ?></span>
            <div class="subject-info">
                <h3><?= sanitize($subject['name']) ?></h3>
                <p><?= sanitize(truncate($subject['description'] ?? '', 100)) ?></p>
                <span class="subject-count"><?= $subject['paper_count'] ?> <?= $subject['paper_count'] != 1 ? t('subjects.papers') : t('subjects.paper') ?></span>
            </div>
        </a>
        <?php endforeach; ?>
    </div>
</div>
</section>

<?php if (!empty($featuredPapers)): ?>
<section class="featured-section" style="padding:4rem 0;background:linear-gradient(135deg,var(--primary-50) 0%,var(--bg-secondary) 100%);">
<div class="container">
    <div class="section-header">
        <h2><?= t('featured.title') ?></h2>
        <p><?= t('featured.subtitle') ?></p>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(350px,1fr));gap:1.5rem;">
        <?php foreach ($featuredPapers as $paper): ?>
        <div class="paper-card">
            <div class="paper-card-header">                <div>
                    <span class="paper-level-badge"><?= sanitize($paper['exam_level'] ?? 'Other') ?></span>
                    <span class="paper-subject-badge"><?= sanitize($paper['subject_icon'] ?? '📄') ?> <?= sanitize($paper['subject_name']) ?></span>
                </div>
                <span class="paper-year"><?= sanitize($paper['publication_year'] ?? 'N/A') ?></span>
            </div>
            <h3><a href="pages/paper.php?id=<?= $paper['id'] ?>"><?= sanitize($paper['title']) ?></a></h3>
            <p class="paper-authors"><?= sanitize($paper['authors'] ?? 'Unknown authors') ?></p>
            <p class="paper-abstract"><?= sanitize(truncate($paper['abstract'] ?? '', 180)) ?></p>
            <div class="paper-actions">
                <a href="pages/paper.php?id=<?= $paper['id'] ?>" class="btn btn-ghost btn-sm"><?= t('paper.preview') ?></a>
                <a href="api/download.php?id=<?= $paper['id'] ?>" class="btn btn-primary btn-sm">⬇ <?= t('paper.download') ?></a>
            </div>
            <div class="paper-meta">
                <span>👁 <?= $paper['view_count'] ?> <?= t('paper.views') ?></span>
                <span>⬇ <?= $paper['download_count'] ?> <?= t('paper.downloads') ?></span>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
</section>
<?php endif; ?>

<section style="padding:4rem 0;text-align:center;">
<div class="container">
    <h2><?= t('cta.title') ?></h2>
    <p style="color:var(--text-secondary);max-width:500px;margin:0 auto 2rem;"><?= t('cta.subtitle') ?></p>
    <?php if (isLoggedIn()): ?>
        <a href="pages/upload.php" class="btn btn-primary btn-lg">📤 <?= t('cta.upload_button') ?></a>
    <?php else: ?>
        <a href="pages/register.php" class="btn btn-primary btn-lg"><?= t('cta.create_account') ?></a>
        <p style="margin-top:1rem;font-size:0.875rem;color:var(--text-tertiary);"><?= t('cta.already_have') ?> <a href="pages/login.php"><?= t('nav.login') ?></a></p>
    <?php endif; ?>
</div>
</section>

<script>
function clearFilters() {
    document.querySelectorAll('#advancedFilters select').forEach(function(s) { s.value = ''; });
    var searchInput = document.getElementById('searchInput');
    if (searchInput) searchInput.dispatchEvent(new Event('input'));
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
<section id="formations" class="academic-section">
<div class="container">
<h2>Offre pédagogique ENSPD</h2>
<div class="academic-grid">
<div class="academic-card"><h3>Génie Informatique</h3><ul><li>Algorithmique</li><li>Développement Web</li><li>Bases de données</li><li>IA</li></ul></div>
<div class="academic-card"><h3>Génie Civil</h3><ul><li>Structures</li><li>Hydraulique</li><li>Topographie</li></ul></div>
<div class="academic-card"><h3>Génie Électrique</h3><ul><li>Électronique</li><li>Automatisme</li><li>Énergie</li></ul></div>
<div class="academic-card"><h3>Génie Mécanique</h3><ul><li>CAO</li><li>Thermodynamique</li><li>Fabrication</li></ul></div>
</div></div></section>
<section id="formations">

<h2>Nos Filières</h2>

<div class="academic-grid">

<div class="academic-card">
<h3>Génie Informatique</h3>
<p>Développement Web, IA, Réseaux</p>
</div>

<div class="academic-card">
<h3>Génie Civil</h3>
<p>BTP, Structures, Hydraulique</p>
</div>

<div class="academic-card">
<h3>Génie Électrique</h3>
<p>Électronique, Énergie, Automatisme</p>
</div>

<div class="academic-card">
<h3>Génie Mécanique</h3>
<p>CAO, Thermodynamique, Fabrication</p>
</div>

</div>

</section>
.academic-grid{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
gap:20px;
}

.academic-card{
padding:20px;
border:2px solid #D4AF37;
border-radius:15px;
background:white;
}
<div class="academic-card">
<h3>Génie Mécanique</h3>
<p>CAO, Thermodynamique, Fabrication</p>
</div>

</div>

</section>
.formations{
    padding:80px 20px;
    background:#ffffff;
}

.formations h2{
    text-align:center;
    color:#0A4D8C;
    margin-bottom:40px;
}

.academic-grid{
    display:grid;
    grid-template-columns:repeat(
        auto-fit,
        minmax(250px,1fr)
    );
    gap:25px;
}

.academic-card{
    background:white;
    border:2px solid #D4AF37;
    border-radius:15px;
    padding:25px;
    transition:.3s;
}

.academic-card:hover{
    transform:translateY(-5px);
}

.academic-card h3{
    color:#0A4D8C;
}


