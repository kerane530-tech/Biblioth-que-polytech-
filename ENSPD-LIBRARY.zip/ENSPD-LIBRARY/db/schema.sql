-- ============================================================
-- CamExamHub — Extended Database Schema
-- ============================================================
SET NAMES utf8mb4;
SET CHARACTER SET utf8mb4;

CREATE DATABASE IF NOT EXISTS `camexamhub`
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE `camexamhub`;

-- ============================================================
-- TABLE: users
-- ============================================================
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(50) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `full_name` VARCHAR(100) DEFAULT NULL,
  `role` ENUM('user', 'admin') NOT NULL DEFAULT 'user',
  `avatar_path` VARCHAR(255) DEFAULT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_users_email` (`email`),
  UNIQUE KEY `uk_users_username` (`username`),
  INDEX `idx_users_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: subjects
-- ============================================================
DROP TABLE IF EXISTS `subjects`;
CREATE TABLE `subjects` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `slug` VARCHAR(100) NOT NULL,
  `description` TEXT DEFAULT NULL,
  `icon` VARCHAR(50) DEFAULT NULL,
  `paper_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_subjects_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================-- TABLE: papers (Extended)
-- ============================================================
DROP TABLE IF EXISTS `papers`;
CREATE TABLE `papers` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `subject_id` INT UNSIGNED NOT NULL,
  `uploaded_by` INT UNSIGNED NOT NULL,
  `title` VARCHAR(300) NOT NULL,
  `authors` VARCHAR(500) DEFAULT NULL,
  `abstract` TEXT DEFAULT NULL,
  `keywords` VARCHAR(500) DEFAULT NULL,
  `topics` VARCHAR(500) DEFAULT NULL COMMENT 'Comma-separated topics',
  `publication_year` YEAR DEFAULT NULL,
  `journal` VARCHAR(200) DEFAULT NULL,
  `doi` VARCHAR(100) DEFAULT NULL,
  `exam_level` ENUM('O-Level', 'A-Level', 'University', 'Professional', 'Other') DEFAULT 'Other',
  `difficulty` ENUM('Easy', 'Medium', 'Hard') DEFAULT 'Medium',
  `file_path` VARCHAR(500) NOT NULL,
  `file_name` VARCHAR(255) NOT NULL,
  `file_size` INT UNSIGNED NOT NULL DEFAULT 0,
  `file_type` VARCHAR(10) NOT NULL DEFAULT 'pdf',
  `page_count` INT UNSIGNED DEFAULT NULL,
  `download_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `view_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `helpful_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `not_helpful_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `is_featured` TINYINT(1) NOT NULL DEFAULT 0,
  `status` ENUM('pending', 'approved', 'rejected') NOT NULL DEFAULT 'pending',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_papers_subject` (`subject_id`),
  INDEX `idx_papers_uploader` (`uploaded_by`),
  INDEX `idx_papers_status` (`status`),
  INDEX `idx_papers_level` (`exam_level`),
  INDEX `idx_papers_created` (`created_at`),
  FULLTEXT KEY `ft_papers_search` (`title`, `authors`, `abstract`, `keywords`, `topics`),
  CONSTRAINT `fk_papers_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_papers_user` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: downloads
-- ============================================================
DROP TABLE IF EXISTS `downloads`;
CREATE TABLE `downloads` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED DEFAULT NULL,
  `paper_id` INT UNSIGNED NOT NULL,
  `ip_address` VARCHAR(45) DEFAULT NULL,  `user_agent` VARCHAR(500) DEFAULT NULL,
  `downloaded_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_downloads_paper` (`paper_id`),
  INDEX `idx_downloads_user` (`user_id`),
  CONSTRAINT `fk_downloads_paper` FOREIGN KEY (`paper_id`) REFERENCES `papers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_downloads_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: paper_feedback
-- ============================================================
DROP TABLE IF EXISTS `paper_feedback`;
CREATE TABLE `paper_feedback` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `paper_id` INT UNSIGNED NOT NULL,
  `user_id` INT UNSIGNED DEFAULT NULL,
  `is_helpful` TINYINT(1) NOT NULL,
  `ip_address` VARCHAR(45) DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_feedback_user_paper` (`user_id`, `paper_id`),
  INDEX `idx_feedback_paper` (`paper_id`),
  CONSTRAINT `fk_feedback_paper` FOREIGN KEY (`paper_id`) REFERENCES `papers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_feedback_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: app_settings
-- ============================================================
DROP TABLE IF EXISTS `app_settings`;
CREATE TABLE `app_settings` (
  `key_name` VARCHAR(100) NOT NULL,
  `key_value` TEXT DEFAULT NULL,
  `description` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`key_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- SEED DATA
-- ============================================================
INSERT INTO `subjects` (`name`, `slug`, `description`, `icon`) VALUES
('Mathematics', 'mathematics', 'Pure and applied mathematics', '📐'),
('Physics', 'physics', 'Classical and modern physics', '⚛️'),
('Chemistry', 'chemistry', 'Organic and inorganic chemistry', '🧪'),
('Biology', 'biology', 'Life sciences and genetics', ''),
('Economics', 'economics', 'Micro and macroeconomics', '📊'),
('Computer Science', 'computer-science', 'Programming and algorithms', '💻'),
('English', 'english', 'Language and literature', '📖'),
('French', 'french', 'Langue et littérature', '🇷'),('History', 'history', 'World and regional history', '️'),
('Geography', 'geography', 'Physical and human geography', '🌍');

INSERT INTO `users` (`username`, `email`, `password_hash`, `full_name`, `role`) VALUES
('admin', 'admin@camexamhub.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrator', 'admin'),
('demo_user', 'demo@camexamhub.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Demo User', 'user');

INSERT INTO `app_settings` (`key_name`, `key_value`, `description`) VALUES
('max_file_size', '52428800', 'Maximum file size in bytes (50MB)'),
('allowed_extensions', 'pdf,docx,txt,rtf', 'Comma-separated allowed file extensions'),
('papers_per_page', '12', 'Number of papers per page'),
('app_name', 'CamExamHub', 'Application name'),
('maintenance_mode', '0', 'Enable maintenance mode (0 or 1)');

INSERT INTO `papers` (`subject_id`, `uploaded_by`, `title`, `authors`, `abstract`, `keywords`, `topics`, `publication_year`, `journal`, `exam_level`, `difficulty`, `file_path`, `file_name`, `file_size`, `file_type`, `page_count`, `status`, `is_featured`, `download_count`, `view_count`, `helpful_count`) VALUES
(5, 1, 'GCE A-Level Economics 2023', 'Cameroon GCE Board', 'December 2023 Economics paper covering microeconomics, macroeconomics, and development economics. This comprehensive examination tests students understanding of economic principles, market structures, fiscal policy, and international trade.', 'economics, GCE, A-Level, microeconomics, macroeconomics', 'Microeconomics,Macroeconomics,Development Economics', 2023, 'GCE Board Cameroon', 'A-Level', 'Medium', '', 'gce_a_level_economics_2023.pdf', 2726297, 'pdf', 14, 'approved', 1, 250, 890, 31),
(8, 1, 'GCE O-Level French 2024', 'Cameroon GCE Board', 'June 2024 French Language paper with comprehension, grammar, and essay writing sections. Tests proficiency in reading, writing, and understanding French at the ordinary level.', 'french, GCE, O-Level, language', 'Compréhension,Grammaire,Rédaction', 2024, 'GCE Board Cameroon', 'O-Level', 'Medium', '', 'gce_o_level_french_2024.pdf', 1845200, 'pdf', 10, 'approved', 0, 180, 620, 24),
(1, 1, 'GCE A-Level Mathematics 2024', 'Cameroon GCE Board', 'Advanced mathematics examination covering calculus, algebra, statistics, and mechanics. Includes both pure and applied mathematics sections.', 'mathematics, calculus, algebra, statistics', 'Calculus,Algebra,Statistics,Mechanics', 2024, 'GCE Board Cameroon', 'A-Level', 'Hard', '', 'gce_a_level_maths_2024.pdf', 3201024, 'pdf', 18, 'approved', 1, 320, 1100, 45),
(2, 1, 'GCE O-Level Physics 2023', 'Cameroon GCE Board', 'Physics examination covering mechanics, waves, electricity, and modern physics. Practical and theoretical questions included.', 'physics, mechanics, waves, electricity', 'Mechanics,Waves,Electricity,Modern Physics', 2023, 'GCE Board Cameroon', 'O-Level', 'Medium', '', 'gce_o_level_physics_2023.pdf', 2105344, 'pdf', 12, 'approved', 0, 195, 710, 28);
