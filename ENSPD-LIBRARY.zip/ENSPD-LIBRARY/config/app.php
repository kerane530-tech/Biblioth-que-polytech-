<<?php
if (!defined('APP_RUNNING')) {
    http_response_code(403);
    exit('Direct access not permitted');
}

// Database
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'camexamhub');

// Application
define('APP_NAME', 'ENSPD-LIBRARY');
define('APP_URL', 'http://localhost/CAMEXAMHUB');
define('APP_PATH', dirname(__DIR__));
define('UPLOAD_DIR', APP_PATH . '/uploads/papers/');
define('AVATAR_DIR', APP_PATH . '/uploads/avatars/');
define('UPLOAD_URL', APP_URL . '/uploads/');

// Upload Limits
define('ALLOWED_EXTENSIONS', ['pdf', 'docx', 'txt', 'rtf']);
define('MAX_FILE_SIZE', 50 * 1024 * 1024);
define('MAX_USERNAME_LENGTH', 50);
define('MIN_PASSWORD_LENGTH', 6);

// Session
define('SESSION_TIMEOUT', 8 * 60 * 60);
define('SESSION_NAME', 'camexamhub_session');

// Pagination
define('PER_PAGE', 12);

// Languages
define('SUPPORTED_LANGUAGES', ['en', 'fr']);
define('DEFAULT_LANGUAGE', 'en');

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);