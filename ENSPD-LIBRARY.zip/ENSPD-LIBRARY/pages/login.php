<?php
/**
 * ============================================================
 * Login Page (login.php)
 * ============================================================
 * 
 * Handles user authentication with:
 * - Email/password login form
 * - CSRF protection
 * - Session creation on success
 * - Redirect after login support
 * - Error display with flash messages
 * 
 * If already logged in, redirects to homepage.
 * ============================================================
 */

// Initialize the application
require_once 'C:\xampp\htdocs\CAMEXAMHUB\includes\bootstrap.php';

// If already logged in, redirect to homepage
if (isLoggedIn()) {
    header('Location: ' . APP_URL . '/index.php');
    exit;
}

// Page variables
$pageTitle = 'Log In';
$activePage = 'login';
$error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || !validateCSRFToken($_POST['csrf_token'])) {
        $error = 'Invalid form submission. Please try again.';
    } else {
        // Attempt login
        $result = loginUser(
            $_POST['email'] ?? '',
            $_POST['password'] ?? ''
        );
        
        if ($result['success']) {
            // Login successful — redirect to intended page or homepage
            setFlash('success', $result['message']);
            $redirect = getPostLoginRedirect();
            header('Location: ' . $redirect);
            exit;
        } else {
            $error = $result['message'];
        }
    }
}

// Generate CSRF token for the form
$csrfToken = generateCSRFToken();

// Include header template
require_once __DIR__ . '/../includes/header.php';
?>

<div class="auth-page">
    <div class="auth-card">
        <h1>Welcome Back</h1>
        <p class="subtitle">Sign in to your ENSPD-LIBRARY account</p>
        
        <!-- Error message display -->
        <?php if ($error): ?>
            <div class="alert alert-error" style="margin-bottom: 1.5rem;">
                <span class="alert-icon">✕</span>
                <span><?= sanitize($error) ?></span>
            </div>
        <?php endif; ?>
        
        <!-- Login Form -->
        <form method="POST" action="" class="needs-validation">
            <!-- CSRF protection token -->
            <input type="hidden" name="csrf_token" value="<?= sanitize($csrfToken) ?>">
            
            <div class="form-group">
                <label for="email">
                    Email Address <span class="required">*</span>
                </label>
                <input 
                    type="email" 
                    id="email" 
                    name="email" 
                    class="form-control" 
                    placeholder="you@example.com"
                    required
                    value="<?= sanitize($_POST['email'] ?? '') ?>"
                    autocomplete="email"
                >
            </div>
            
            <div class="form-group">
                <label for="password">
                    Password <span class="required">*</span>
                </label>
                <input 
                    type="password" 
                    id="password" 
                    name="password" 
                    class="form-control" 
                    placeholder="Enter your password"
                    required
                    autocomplete="current-password"
                >
            </div>
            
            <button type="submit" class="btn btn-primary">
                Sign In
            </button>
        </form>
        
        <div class="auth-links">
            Don't have an account? <a href="register.php">Create one</a>
        </div>
        
        <!-- Demo credentials hint -->
        <div style="margin-top: 1.5rem; padding: 1rem; background: var(--info-light); border-radius: var(--radius-md); font-size: var(--text-xs); color: var(--info);">
            <strong>Demo Account:</strong><br>
            Email: demo@example.com<br>
            Password: password
        </div>
    </div>
</div>

<?php
// Include footer template
require_once __DIR__ . '/../includes/footer.php';
?>
