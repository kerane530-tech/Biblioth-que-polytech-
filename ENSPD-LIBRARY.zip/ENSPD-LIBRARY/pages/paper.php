<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$paperId = (int)($_GET['id'] ?? 0);
if ($paperId <= 0) { setFlash('error', 'Invalid paper ID.'); header('Location: browse.php'); exit; }
$paper = getPaper($paperId);
if (!$paper) { setFlash('error', 'Paper not found.'); header('Location: browse.php'); exit; }

$pageTitle = $paper['title'];
$activePage = 'browse';
$currentUser = getCurrentUser();

$relatedPapers = dbFetchAll(
    "SELECT p.*, s.name AS subject_name, s.icon AS subject_icon
     FROM papers p JOIN subjects s ON p.subject_id = s.id
     WHERE p.subject_id = ? AND p.id != ? AND p.status = 'approved'
     ORDER BY p.download_count DESC LIMIT 3",
    [$paper['subject_id'], $paperId]
);

$keywords = array_filter(array_map('trim', explode(',', $paper['keywords'] ?? '')));
$topics = array_filter(array_map('trim', explode(',', $paper['topics'] ?? '')));

// Check if user already voted
$userVoted = false;
if ($currentUser) {
    $vote = dbFetchOne("SELECT is_helpful FROM paper_feedback WHERE paper_id = ? AND user_id = ?", [$paperId, $currentUser['id']]);
    if ($vote) $userVoted = $vote['is_helpful'];
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container paper-detail">
<div class="paper-detail-layout">
    <div class="paper-detail-main">
        <div style="margin-bottom:1rem;">
            <a href="browse.php?subject=<?= sanitize($paper['subject_slug']) ?>" class="paper-subject-badge" style="text-decoration:none;">
                <?= sanitize($paper['subject_icon'] ?? '📄') ?> <?= sanitize($paper['subject_name']) ?>
            </a>
            <span class="paper-level-badge" style="margin-left:0.5rem;"><?= sanitize($paper['exam_level'] ?? 'Other') ?></span>
            <span class="paper-difficulty-badge" style="margin-left:0.5rem;"><?= sanitize($paper['difficulty'] ?? 'Medium') ?></span>
        </div>
        <h1><?= sanitize($paper['title']) ?></h1>
        <div class="paper-detail-meta">
            <?php if ($paper['authors']): ?><div class="meta-item"><strong><?= t('detail.authors') ?>:</strong> <?= sanitize($paper['authors']) ?></div><?php endif; ?>
            <?php if ($paper['publication_year']): ?><div class="meta-item"><strong><?= t('detail.year') ?>:</strong> <?= sanitize($paper['publication_year']) ?></div><?php endif; ?>
            <?php if ($paper['journal']): ?><div class="meta-item"><strong><?= t('detail.published_in') ?>:</strong> <?= sanitize($paper['journal']) ?></div><?php endif; ?>
            <div class="meta-item"><strong><?= t('detail.uploaded_by') ?>:</strong> <?= sanitize($paper['uploader_name']) ?></div>
            <div class="meta-item"><strong><?= t('detail.date') ?>:</strong> <?= formatDate($paper['created_at']) ?></div>
        </div>        
        <?php if ($paper['abstract']): ?>
        <div class="paper-abstract-full">
            <h2><?= t('detail.abstract') ?></h2>
            <p><?= nl2br(sanitize($paper['abstract'])) ?></p>
        </div>
        <?php endif; ?>
        
        <?php if (!empty($topics)): ?>
        <div style="margin-bottom:1.5rem;">
            <strong style="font-size:0.875rem;color:var(--text-secondary);"><?= t('detail.topics') ?>:</strong>
            <div class="paper-keywords" style="margin-top:0.5rem;">
                <?php foreach ($topics as $topic): ?><span class="keyword-tag"><?= sanitize($topic) ?></span><?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if (!empty($keywords)): ?>
        <div>
            <strong style="font-size:0.875rem;color:var(--text-secondary);"><?= t('detail.keywords') ?>:</strong>
            <div class="paper-keywords" style="margin-top:0.5rem;">
                <?php foreach ($keywords as $keyword): ?><span class="keyword-tag"><?= sanitize($keyword) ?></span><?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <div style="padding:1.5rem;background:var(--bg-tertiary);border-radius:var(--radius-lg);margin-top:2rem;">
            <h3 style="font-size:1.125rem;margin-bottom:1rem;"><?= t('detail.file_info') ?></h3>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;font-size:0.875rem;">
                <div><strong><?= t('detail.file_name') ?>:</strong> <?= sanitize($paper['file_name']) ?></div>
                <div><strong><?= t('detail.file_type') ?>:</strong> <?= strtoupper(sanitize($paper['file_type'])) ?></div>
                <div><strong><?= t('detail.file_size') ?>:</strong> <?= formatFileSize($paper['file_size']) ?></div>
                <div><strong><?= t('paper.downloads') ?>:</strong> <?= number_format($paper['download_count']) ?></div>
                <?php if ($paper['page_count']): ?><div><strong><?= t('paper.pages') ?>:</strong> <?= $paper['page_count'] ?></div><?php endif; ?>
            </div>
        </div>
        
        <!-- Feedback Section -->
        <div class="feedback-section">
            <h4><?= t('detail.was_helpful') ?></h4>
            <div class="feedback-buttons">
                <button class="feedback-btn <?= $userVoted === 1 ? 'active-helpful' : '' ?>" data-paper-id="<?= $paperId ?>" data-helpful="1">
                    👍 <?= t('paper.helpful') ?> (<?= $paper['helpful_count'] ?>)
                </button>
                <button class="feedback-btn <?= $userVoted === 0 ? 'active-not-helpful' : '' ?>" data-paper-id="<?= $paperId ?>" data-helpful="0">
                    👎 <?= t('paper.not_helpful') ?> (<?= $paper['not_helpful_count'] ?>)
                </button>
            </div>
            <div id="feedbackThanks" style="display:none;margin-top:1rem;padding:1rem;background:var(--primary-50);border-radius:var(--radius-md);color:var(--primary);font-size:0.875rem;">
                ✓ <?= t('detail.feedback_thanks') ?>            </div>
        </div>
    </div>
    
    <div class="paper-detail-sidebar">
        <div class="sidebar-card">
            <h3>📥 <?= t('detail.download_paper') ?></h3>
            <div class="sidebar-stats">
                <div class="sidebar-stat"><span class="sidebar-stat-value"><?= number_format($paper['download_count']) ?></span><span class="sidebar-stat-label"><?= t('paper.downloads') ?></span></div>
                <div class="sidebar-stat"><span class="sidebar-stat-value"><?= number_format($paper['view_count']) ?></span><span class="sidebar-stat-label"><?= t('paper.views') ?></span></div>
            </div>
            <a href="../api/download.php?id=<?= $paper['id'] ?>" class="btn btn-primary download-btn">⬇ <?= t('paper.download') ?> <?= strtoupper(sanitize($paper['file_type'])) ?></a>
            <p style="font-size:0.75rem;color:var(--text-tertiary);text-align:center;margin-top:0.75rem;margin-bottom:0;"><?= formatFileSize($paper['file_size']) ?> • <?= strtoupper(sanitize($paper['file_type'])) ?></p>
        </div>
        <div class="sidebar-card">
            <h3>👤 <?= t('detail.uploaded_by') ?></h3>
            <div style="display:flex;align-items:center;gap:0.75rem;">
                <div style="width:40px;height:40px;border-radius:50%;background:var(--primary);color:white;display:flex;align-items:center;justify-content:center;font-weight:600;"><?= strtoupper(substr($paper['uploader_name'], 0, 1)) ?></div>
                <div>
                    <div style="font-weight:600;font-size:0.875rem;"><?= sanitize($paper['uploader_name']) ?></div>
                    <div style="font-size:0.75rem;color:var(--text-tertiary);"><?= t('detail.member_since') ?> <?= formatDate($paper['created_at'] ?? date('Y-m-d'), 'M Y') ?></div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if (!empty($relatedPapers)): ?>
<div style="margin-top:3rem;">
    <h2 style="margin-bottom:1.5rem;"><?= t('detail.related_papers') ?></h2>
    <div class="papers-grid" style="grid-template-columns:repeat(auto-fill,minmax(300px,1fr));">
        <?php foreach ($relatedPapers as $related): ?>
        <div class="paper-card">
            <div class="paper-card-header">
                <span class="paper-subject-badge"><?= sanitize($related['subject_icon'] ?? '') ?> <?= sanitize($related['subject_name']) ?></span>
                <span class="paper-year"><?= sanitize($related['publication_year'] ?? '') ?></span>
            </div>
            <h3><a href="paper.php?id=<?= $related['id'] ?>"><?= sanitize(truncate($related['title'], 100)) ?></a></h3>
            <p class="paper-abstract"><?= sanitize(truncate($related['abstract'] ?? '', 150)) ?></p>
            <div class="paper-actions">
                <a href="paper.php?id=<?= $related['id'] ?>" class="btn btn-ghost btn-sm"><?= t('paper.preview') ?></a>
                <a href="../api/download.php?id=<?= $related['id'] ?>" class="btn btn-primary btn-sm">⬇ <?= t('paper.download') ?></a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>