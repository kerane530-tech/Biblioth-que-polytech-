<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
requireAdmin();
$pageTitle = t('admin_users');
$activePage = 'admin_users';

// Handle Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $userId = (int)$_POST['user_id'];
    if ($_POST['action'] === 'toggle_role') {
        $newRole = $_POST['current_role'] === 'admin' ? 'user' : 'admin';
        dbQuery("UPDATE users SET role = ? WHERE id = ?", [$newRole, $userId]);
        setFlash('success', 'User role updated.');
    } elseif ($_POST['action'] === 'toggle_active') {
        $newStatus = $_POST['current_status'] ? 0 : 1;
        dbQuery("UPDATE users SET is_active = ? WHERE id = ?", [$newStatus, $userId]);
        setFlash('success', 'User status updated.');
    } elseif ($_POST['action'] === 'delete') {
        dbQuery("DELETE FROM users WHERE id = ?", [$userId]);
        setFlash('success', 'User deleted.');
    }
    header('Location: ' . $_SERVER['REQUEST_URI']); exit;
}

$users = dbFetchAll("SELECT * FROM users ORDER BY created_at DESC");
require_once __DIR__ . '/../../includes/header.php';
?>
<div class="container admin-page">
    <h1><i class="fa-solid fa-users-gear"></i> <?= t('admin_users') ?></h1>
    <div class="admin-table-wrapper">
        <table class="admin-table">
            <thead><tr><th>ID</th><th>Username</th><th>Email</th><th>Role</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
                <?php foreach ($users as $u): ?>
                <tr>
                    <td><?= $u['id'] ?></td>
                    <td><?= sanitize($u['username']) ?></td>
                    <td><?= sanitize($u['email']) ?></td>
                    <td><span class="badge badge-<?= $u['role'] === 'admin' ? 'primary' : 'secondary' ?>"><?= $u['role'] ?></span></td>
                    <td><span class="badge badge-<?= $u['is_active'] ? 'success' : 'danger' ?>"><?= $u['is_active'] ? 'Active' : 'Disabled' ?></span></td>
                    <td class="actions">
                        <form method="POST" style="display:inline;"><input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                            <input type="hidden" name="current_role" value="<?= $u['role'] ?>">
                            <button name="action" value="toggle_role" class="btn btn-sm btn-ghost"><i class="fa-solid fa-user-tag"></i></button>
                        </form>
                        <form method="POST" style="display:inline;"><input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                            <input type="hidden" name="current_status" value="<?= $u['is_active'] ?>">
                            <button name="action" value="toggle_active" class="btn btn-sm btn-ghost"><i class="fa-solid fa-power-off"></i></button>
                        </form>
                        <form method="POST" style="display:inline;" onsubmit="return confirm('Delete user?');"><input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                            <button name="action" value="delete" class="btn btn-sm btn-danger"><i class="fa-solid fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>