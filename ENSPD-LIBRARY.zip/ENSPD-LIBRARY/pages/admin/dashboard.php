<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
requireAdmin();
$pageTitle = t('admin_dashboard');
$activePage = 'admin_dashboard';

$stats = [
    'users' => dbFetchOne("SELECT COUNT(*) as c FROM users")['c'],
    'papers' => dbFetchOne("SELECT COUNT(*) as c FROM papers")['c'],
    'downloads' => dbFetchOne("SELECT COALESCE(SUM(download_count),0) as c FROM papers")['c'],
    'pending' => dbFetchOne("SELECT COUNT(*) as c FROM papers WHERE status='pending'")['c']
];
require_once __DIR__ . '/../../includes/header.php';
?>
<div class="container admin-page">
    <h1><i class="fa-solid fa-gauge-high"></i> <?= t('admin_dashboard') ?></h1>
    <div class="admin-stats-grid">
        <div class="admin-stat-card"><i class="fa-solid fa-users"></i><h3><?= $stats['users'] ?></h3><p>Users</p></div>
        <div class="admin-stat-card"><i class="fa-solid fa-file-lines"></i><h3><?= $stats['papers'] ?></h3><p>Papers</p></div>
        <div class="admin-stat-card"><i class="fa-solid fa-download"></i><h3><?= $stats['downloads'] ?></h3><p>Downloads</p></div>
        <div class="admin-stat-card pending"><i class="fa-solid fa-clock"></i><h3><?= $stats['pending'] ?></h3><p>Pending Review</p></div>
    </div>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>