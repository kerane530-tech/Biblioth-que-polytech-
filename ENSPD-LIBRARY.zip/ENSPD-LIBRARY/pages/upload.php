<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requireLogin();
$pageTitle = t('upload.title');
$activePage = 'upload';
$errors = [];
$success = false;
$subjects = getSubjects();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !validateCSRFToken($_POST['csrf_token'])) {
        $errors[] = 'Invalid form submission.';
    } else {
        $title = trim($_POST['title'] ?? '');
        $subjectId = (int)($_POST['subject_id'] ?? 0);
        $authors = trim($_POST['authors'] ?? '');
        $abstract = trim($_POST['abstract'] ?? '');
        $keywords = trim($_POST['keywords'] ?? '');
        $topics = trim($_POST['topics'] ?? '');
        $year = (int)($_POST['publication_year'] ?? 0);
        $journal = trim($_POST['journal'] ?? '');
        $doi = trim($_POST['doi'] ?? '');
        $examLevel = $_POST['exam_level'] ?? 'Other';
        $difficulty = $_POST['difficulty'] ?? 'Medium';
        
        if (strlen($title) < 5) $errors[] = 'Title must be at least 5 characters.';
        if ($subjectId <= 0) $errors[] = 'Please select a subject.';
        if ($year > 0 && ($year < 1900 || $year > (int)date('Y') + 1)) $errors[] = 'Invalid year.';
        if (!isset($_FILES['paper_file']) || $_FILES['paper_file']['error'] === UPLOAD_ERR_NO_FILE) {
            $errors[] = 'Please select a file.';
        }
        
        if (empty($errors)) {
            $uploadResult = handleUpload($_FILES['paper_file'], UPLOAD_DIR, ALLOWED_EXTENSIONS);
            if ($uploadResult['success']) {
                $fileSize = $_FILES['paper_file']['size'];
                $fileExt = strtolower(pathinfo($uploadResult['name'], PATHINFO_EXTENSION));
                dbQuery(
                    "INSERT INTO papers (subject_id, uploaded_by, title, authors, abstract, keywords, topics,
                     publication_year, journal, doi, exam_level, difficulty, file_path, file_name, file_size, file_type, status)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'approved')",
                    [$subjectId, $_SESSION['user_id'], $title, $authors, $abstract, $keywords, $topics,
                     $year > 0 ? $year : null, $journal, $doi, $examLevel, $difficulty,
                     $uploadResult['saved'], $uploadResult['name'], $fileSize, $fileExt]
                );
                dbQuery("UPDATE subjects SET paper_count = (SELECT COUNT(*) FROM papers WHERE subject_id = ? AND status = 'approved') WHERE id = ?", [$subjectId, $subjectId]);
                $success = true;
                setFlash('success', t('upload.success_title'));
            } else {
                $errors[] = 'File upload failed: ' . $uploadResult['error'];            }
        }
    }
}
$csrfToken = generateCSRFToken();
require_once __DIR__ . '/../includes/header.php';
?>

<div class="container upload-page">
<?php if ($success): ?>
<div class="upload-card" style="text-align:center;">
    <div style="font-size:4rem;margin-bottom:1rem;">✅</div>
    <h1 style="margin-bottom:1rem;"><?= t('upload.success_title') ?></h1>
    <p style="color:var(--text-secondary);margin-bottom:2rem;max-width:400px;margin-left:auto;margin-right:auto;"><?= t('upload.success_desc') ?></p>
    <div style="display:flex;gap:1rem;justify-content:center;">
        <a href="browse.php" class="btn btn-ghost"><?= t('upload.browse_papers') ?></a>
        <a href="upload.php" class="btn btn-primary"><?= t('upload.upload_another') ?></a>
    </div>
</div>
<?php else: ?>
<div class="upload-card">
    <h1>📤 <?= t('upload.title') ?></h1>
    <?php if (!empty($errors)): ?>
    <div class="alert alert-error" style="margin-bottom:1.5rem;">
        <span class="alert-icon">✕</span>
        <div><?php foreach ($errors as $err): ?><div><?= sanitize($err) ?></div><?php endforeach; ?></div>
    </div>
    <?php endif; ?>
    <form method="POST" action="" enctype="multipart/form-data" class="needs-validation">
        <input type="hidden" name="csrf_token" value="<?= sanitize($csrfToken) ?>">
        <div class="form-group">
            <label><?= t('upload.file_label') ?> <span class="required">*</span></label>
            <div class="upload-dropzone" id="uploadDropzone">
                <div class="upload-dropzone-icon">📄</div>
                <h3><?= t('upload.drag_drop') ?></h3>
                <p><?= t('upload.or_click') ?> • <?= t('upload.file_types') ?> • <?= t('upload.max_size') ?></p>
                <input type="file" name="paper_file" id="fileInput" class="file-input" accept=".pdf,.docx,.txt,.rtf" required>
            </div>
            <div class="upload-file-info" id="fileInfo">
                <span class="file-icon">📎</span>
                <div class="file-details">
                    <h4 class="file-name-text">filename.pdf</h4>
                    <p class="file-size-text">0 KB</p>
                </div>
            </div>
        </div>
        <div class="form-group">
            <label for="title"><?= t('upload.paper_title') ?> <span class="required">*</span></label>
            <input type="text" id="title" name="title" class="form-control" required minlength="5" value="<?= sanitize($_POST['title'] ?? '') ?>">
        </div>        <div class="form-group">
            <label for="subject_id"><?= t('upload.subject') ?> <span class="required">*</span></label>
            <select id="subject_id" name="subject_id" class="form-control" required>
                <option value="0"><?= t('upload.select_subject') ?></option>
                <?php foreach ($subjects as $subject): ?>
                <option value="<?= $subject['id'] ?>" <?= ((int)($_POST['subject_id'] ?? 0) === (int)$subject['id']) ? 'selected' : '' ?>>
                    <?= sanitize($subject['icon'] ?? '') ?> <?= sanitize($subject['name']) ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="upload-form-row">
            <div class="form-group">
                <label for="exam_level"><?= t('upload.exam_level') ?></label>
                <select id="exam_level" name="exam_level" class="form-control">
                    <option value="Other">Other</option>
                    <option value="O-Level" <?= ($_POST['exam_level'] ?? '') === 'O-Level' ? 'selected' : '' ?>>O-Level</option>
                    <option value="A-Level" <?= ($_POST['exam_level'] ?? '') === 'A-Level' ? 'selected' : '' ?>>A-Level</option>
                    <option value="University" <?= ($_POST['exam_level'] ?? '') === 'University' ? 'selected' : '' ?>>University</option>
                    <option value="Professional" <?= ($_POST['exam_level'] ?? '') === 'Professional' ? 'selected' : '' ?>>Professional</option>
                </select>
            </div>
            <div class="form-group">
                <label for="difficulty"><?= t('upload.difficulty') ?></label>
                <select id="difficulty" name="difficulty" class="form-control">
                    <option value="Easy" <?= ($_POST['difficulty'] ?? '') === 'Easy' ? 'selected' : '' ?>>Easy</option>
                    <option value="Medium" <?= ($_POST['difficulty'] ?? '') !== 'Easy' && ($_POST['difficulty'] ?? '') !== 'Hard' ? 'selected' : '' ?>>Medium</option>
                    <option value="Hard" <?= ($_POST['difficulty'] ?? '') === 'Hard' ? 'selected' : '' ?>>Hard</option>
                </select>
            </div>
        </div>
        <div class="upload-form-row">
            <div class="form-group">
                <label for="authors"><?= t('upload.authors') ?></label>
                <input type="text" id="authors" name="authors" class="form-control" value="<?= sanitize($_POST['authors'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label for="publication_year"><?= t('upload.publication_year') ?></label>
                <input type="number" id="publication_year" name="publication_year" class="form-control" min="1900" max="<?= (int)date('Y') + 1 ?>" value="<?= sanitize($_POST['publication_year'] ?? '') ?>">
            </div>
        </div>
        <div class="upload-form-row">
            <div class="form-group">
                <label for="journal"><?= t('upload.journal') ?></label>
                <input type="text" id="journal" name="journal" class="form-control" value="<?= sanitize($_POST['journal'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label for="doi"><?= t('upload.doi') ?></label>
                <input type="text" id="doi" name="doi" class="form-control" value="<?= sanitize($_POST['doi'] ?? '') ?>">
            </div>        </div>
        <div class="form-group">
            <label for="abstract"><?= t('upload.abstract') ?></label>
            <textarea id="abstract" name="abstract" class="form-control" rows="6" placeholder="<?= t('upload.abstract_placeholder') ?>"><?= sanitize($_POST['abstract'] ?? '') ?></textarea>
        </div>
        <div class="upload-form-row">
            <div class="form-group">
                <label for="keywords"><?= t('upload.keywords') ?></label>
                <input type="text" id="keywords" name="keywords" class="form-control" value="<?= sanitize($_POST['keywords'] ?? '') ?>">
                <span class="form-hint"><?= t('upload.keywords_hint') ?></span>
            </div>
            <div class="form-group">
                <label for="topics"><?= t('upload.topics') ?></label>
                <input type="text" id="topics" name="topics" class="form-control" value="<?= sanitize($_POST['topics'] ?? '') ?>">
                <span class="form-hint"><?= t('upload.topics_hint') ?></span>
            </div>
        </div>
        <div style="margin-top:2rem;">
            <button type="submit" class="btn btn-primary btn-lg" style="width:100%;">📤 <?= t('upload.submit') ?></button>
        </div>
    </form>
</div>
<?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>