<?php
/**
 * ============================================================
 * Registration Page (register.php)
 * ============================================================
 * 
 * Creates new user accounts with:
 * - Username, email, password, and full name fields
 * - Input validation (length, format, uniqueness)
 * - Password confirmation
 * - CSRF protection
 * - Automatic redirect to login after success
 * ============================================================
 */

// Initialize the application
require_once  'C:\xampp\htdocs\CAMEXAMHUB\includes\bootstrap.php';

// Redirect if already logged in
if (isLoggedIn()) {
    header('Location: ' . APP_URL . '/index.php');
    exit;
}

// Page variables
$pageTitle = 'Create Account';
$activePage = 'register';
$error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || !validateCSRFToken($_POST['csrf_token'])) {
        $error = 'Invalid form submission. Please try again.';
    } else {
        // Attempt registration
        $result = registerUser(
            $_POST['username'] ?? '',
            $_POST['email'] ?? '',
            $_POST['password'] ?? '',
            $_POST['confirm_password'] ?? '',
            $_POST['full_name'] ?? ''
        );
        
        if ($result['success']) {
            // Registration successful — redirect to login
            setFlash('success', $result['message']);
            header('Location: login.php');
            exit;
        } else {
            $error = $result['message'];
        }
    }
}

// Generate CSRF token
$csrfToken = generateCSRFToken();

// Include header
require_once __DIR__ . '/../includes/header.php';
?>

<div class="auth-page">
    <div class="auth-card">
        <h1>Create Account</h1>
        <p class="subtitle">Join the ENSPD-LIBRARY community</p>
        
        <!-- Error display -->
        <?php if ($error): ?>
            <div class="alert alert-error" style="margin-bottom: 1.5rem;">
                <span class="alert-icon">✕</span>
                <span><?= sanitize($error) ?></span>
            </div>
        <?php endif; ?>
        
        <!-- Registration Form -->
        <form method="POST" action="" class="needs-validation">
            <input type="hidden" name="csrf_token" value="<?= sanitize($csrfToken) ?>">
            
            <div class="form-group">
                <label for="username">
                    Username <span class="required">*</span>
                </label>
                <input 
                    type="text" 
                    id="username" 
                    name="username" 
                    class="form-control" 
                    placeholder="Choose a username"
                    required
                    minlength="3"
                    maxlength="50"
                    pattern="[a-zA-Z0-9_]+"
                    value="<?= sanitize($_POST['username'] ?? '') ?>"
                    autocomplete="username"
                >
                <span class="form-hint">Letters, numbers, and underscores only. At least 3 characters.</span>
            </div>
            
            <div class="form-group">
                <label for="full_name">
                    Full Name
                </label>
                <input 
                    type="text" 
                    id="full_name" 
                    name="full_name" 
                    class="form-control" 
                    placeholder="Your full name (optional)"
                    value="<?= sanitize($_POST['full_name'] ?? '') ?>"
                    autocomplete="name"
                >
            </div>
            
            <div class="form-group">
                <label for="email">
                    Email Address <span class="required">*</span>
                </label>
                <input 
                    type="email" 
                    id="email" 
                    name="email" 
                    class="form-control" 
                    placeholder="you@example.com"
                    required
                    value="<?= sanitize($_POST['email'] ?? '') ?>"
                    autocomplete="email"
                >
            </div>
            
            <div class="form-group">
                <label for="password">
                    Password <span class="required">*</span>
                </label>
                <input 
                    type="password" 
                    id="password" 
                    name="password" 
                    class="form-control" 
                    placeholder="Create a password"
                    required
                    minlength="6"
                    autocomplete="new-password"
                >
                <span class="form-hint">At least 6 characters.</span>
            </div>
            
            <div class="form-group">
                <label for="confirm_password">
                    Confirm Password <span class="required">*</span>
                </label>
                <input 
                    type="password" 
                    id="confirm_password" 
                    name="confirm_password" 
                    class="form-control" 
                    placeholder="Re-enter your password"
                    required
                    autocomplete="new-password"
                >
            </div>
            
            <button type="submit" class="btn btn-primary">
                Create Account
            </button>
        </form>
        
        <div class="auth-links">
            Already have an account? <a href="login.php">Sign in</a>
        </div>
    </div>
</div>

<?php
// Include footer template
require_once __DIR__ . '/../includes/footer.php';
?>
