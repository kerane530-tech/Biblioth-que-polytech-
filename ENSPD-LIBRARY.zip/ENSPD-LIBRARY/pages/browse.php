<?php
/**
 * ============================================================
 * Browse & Search Page (browse.php)
 * ============================================================
 * 
 * Displays a searchable, filterable list of research papers.
 * Features:
 * - Full-text search with keyword matching
 * - Filter by subject category
 * - Sort by date, downloads, views, or title
 * - Pagination for large result sets
 * - Inline subject preview when selecting a category
 * 
 * URL Parameters:
 *   ?q=search_term    - Search query
 *   ?subject=slug      - Filter by subject slug
 *   ?sort=field        - Sort field (date, downloads, views, title)
 *   ?page=N            - Page number
 * ============================================================
 */

// Initialize the application
require_once 'C:\xampp\htdocs\CAMEXAMHUB\includes\bootstrap.php';

// Page variables
$pageTitle = 'Browse Papers';
$activePage = 'browse';

// Get URL parameters
$searchQuery = trim($_GET['q'] ?? '');
$subjectFilter = trim($_GET['subject'] ?? '');
$sortBy = trim($_GET['sort'] ?? 'date');
$page = max(1, (int)($_GET['page'] ?? 1));

// Fetch all subjects for sidebar filter
$allSubjects = getSubjects();

// Get current subject info if filtering
$currentSubject = null;
if ($subjectFilter) {
    $currentSubject = getSubject($subjectFilter);
    if ($currentSubject) {
        $pageTitle = $currentSubject['name'] . ' Papers';
    }
}

// ============================================================
// Build the search/query
// ============================================================
$whereConditions = ["p.status = 'approved'"];
$params = [];

// Add search conditions if query provided
if ($searchQuery) {
    $search = buildSearchQuery($searchQuery);
    $whereConditions[] = '(' . $search['conditions'] . ')';
    $params = array_merge($params, $search['params']);
}

// Add subject filter
if ($currentSubject) {
    $whereConditions[] = 'p.subject_id = ?';
    $params[] = $currentSubject['id'];
}

// Build ORDER BY clause
$orderMap = [
    'date'      => 'p.created_at DESC',
    'downloads' => 'p.download_count DESC',
    'views'     => 'p.view_count DESC',
    'title'     => 'p.title ASC',
    'year'      => 'p.publication_year DESC',
];
$orderBy = $orderMap[$sortBy] ?? $orderMap['date'];

// Count total results
$whereSQL = implode(' AND ', $whereConditions);
$countResult = dbFetchOne(
    "SELECT COUNT(*) as total FROM papers p WHERE {$whereSQL}",
    $params
);
$totalResults = $countResult['total'] ?? 0;

// Paginate results
$pagination = paginate($totalResults, PER_PAGE, $page, 
    APP_URL . '/pages/browse.php', 
    array_filter(['q' => $searchQuery, 'subject' => $subjectFilter, 'sort' => $sortBy])
);

// Fetch papers for current page
$papers = dbFetchAll(
    "SELECT p.*, s.name AS subject_name, s.slug AS subject_slug, s.icon AS subject_icon,
            u.username AS uploader_name
     FROM papers p
     JOIN subjects s ON p.subject_id = s.id
     JOIN users u ON p.uploaded_by = u.id
     WHERE {$whereSQL}
     ORDER BY {$orderBy}
     LIMIT " . PER_PAGE . " OFFSET {$pagination['offset']}",
    $params
);

// Include header
require_once __DIR__ . '/../includes/header.php';
?>

<div class="container">
    <div class="browse-layout">
        <!-- ====================================================
             Sidebar Filters
             ==================================================== -->
        <aside class="filter-sidebar">
            <form method="GET" action="">
                <!-- Preserve search query -->
                <?php if ($searchQuery): ?>
                    <input type="hidden" name="q" value="<?= sanitize($searchQuery) ?>">
                <?php endif; ?>
                
                <!-- Subject Filter -->
                <div class="filter-group">
                    <h4>Subjects</h4>
                    <label>
                        <input type="radio" name="subject" value="" <?= !$subjectFilter ? 'checked' : '' ?>>
                        All Subjects
                    </label>
                    <?php foreach ($allSubjects as $subject): ?>
                        <label>
                            <input type="radio" name="subject" value="<?= sanitize($subject['slug']) ?>" 
                                   <?= $subjectFilter === $subject['slug'] ? 'checked' : '' ?>>
                            <?= sanitize($subject['icon'] ?? '📄') ?> <?= sanitize($subject['name']) ?>
                        </label>
                    <?php endforeach; ?>
                </div>
                
                <!-- Sort Options -->
                <div class="filter-group">
                    <h4>Sort By</h4>
                    <label>
                        <input type="radio" name="sort" value="date" <?= $sortBy === 'date' ? 'checked' : '' ?>>
                        Newest First
                    </label>
                    <label>
                        <input type="radio" name="sort" value="downloads" <?= $sortBy === 'downloads' ? 'checked' : '' ?>>
                        Most Downloaded
                    </label>
                    <label>
                        <input type="radio" name="sort" value="views" <?= $sortBy === 'views' ? 'checked' : '' ?>>
                        Most Viewed
                    </label>
                    <label>
                        <input type="radio" name="sort" value="title" <?= $sortBy === 'title' ? 'checked' : '' ?>>
                        Title A-Z
                    </label>
                    <label>
                        <input type="radio" name="sort" value="year" <?= $sortBy === 'year' ? 'checked' : '' ?>>
                        Newest Year
                    </label>
                </div>
                
                <button type="submit" class="btn btn-primary btn-sm" style="width: 100%;">Apply Filters</button>
            </form>
        </aside>
        
        <!-- ====================================================
             Papers List
             ==================================================== -->
        <div class="papers-main">
            <!-- Results Header -->
            <div class="papers-header">
                <h2 style="font-size: var(--text-xl); margin: 0;">
                    <?php if ($currentSubject): ?>
                        <?= sanitize($currentSubject['icon'] ?? '📄') ?> <?= sanitize($currentSubject['name']) ?>
                    <?php elseif ($searchQuery): ?>
                        Results for "<?= sanitize($searchQuery) ?>"
                    <?php else: ?>
                        All Papers
                    <?php endif; ?>
                </h2>
                <span class="papers-count">
                    <?= number_format($totalResults) ?> paper<?= $totalResults != 1 ? 's' : '' ?> found
                </span>
            </div>
            
            <!-- Papers Grid -->
            <?php if (!empty($papers)): ?>
                <div class="papers-grid">
                    <?php foreach ($papers as $paper): ?>
                        <div class="paper-card">
                            <div class="paper-card-header">
                                <span class="paper-subject-badge">
                                    <?= sanitize($paper['subject_icon'] ?? '📄') ?> 
                                    <?= sanitize($paper['subject_name']) ?>
                                </span>
                                <span class="paper-year"><?= sanitize($paper['publication_year'] ?? 'N/A') ?></span>
                            </div>
                            <h3>
                                <a href="paper.php?id=<?= $paper['id'] ?>">
                                    <?= sanitize($paper['title']) ?>
                                </a>
                            </h3>
                            <p class="paper-authors"><?= sanitize($paper['authors'] ?? 'Unknown authors') ?></p>
                            <p class="paper-abstract"><?= sanitize(truncate($paper['abstract'] ?? '', 200)) ?></p>
                            <div class="paper-actions">
                                <a href="paper.php?id=<?= $paper['id'] ?>" class="btn btn-ghost btn-sm">Preview</a>
                                <a href="../api/download.php?id=<?= $paper['id'] ?>" class="btn btn-primary btn-sm">⬇ Download</a>
                            </div>
                            <div class="paper-meta">
                                <span>👁 <?= number_format($paper['view_count']) ?></span>
                                <span>⬇ <?= number_format($paper['download_count']) ?></span>
                                <span><?= sanitize($paper['journal'] ?? '') ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <!-- Pagination -->
                <?= $pagination['html'] ?>
            <?php else: ?>
                <!-- Empty State -->
                <div class="empty-state">
                    <div class="empty-state-icon">📭</div>
                    <h2>No papers found</h2>
                    <p>
                        <?php if ($searchQuery): ?>
                            No results match your search for "<?= sanitize($searchQuery) ?>". 
                            Try different keywords or browse all papers.
                        <?php elseif ($currentSubject): ?>
                            No papers have been uploaded for <?= sanitize($currentSubject['name']) ?> yet.
                        <?php else: ?>
                            No papers are available yet. Be the first to upload!
                        <?php endif; ?>
                    </p>
                    <a href="browse.php" class="btn btn-primary">Browse All Papers</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php
// Include footer
require_once __DIR__ . '/../includes/footer.php';
?>
