#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>

#define MAX_PATH 4096
#define BUFFER_SIZE 8192

void process_file(const char *filepath, FILE *output) {
    FILE *input = fopen(filepath, "rb");
    if (!input) {
        fprintf(stderr, "Warning: Could not open file: %s\n", filepath);
        return;
    }

    fprintf(output, "========================================\n");
    fprintf(output, "FILE: %s\n", filepath);
    fprintf(output, "========================================\n");

    char buffer[BUFFER_SIZE];
    size_t bytes_read;
    while ((bytes_read = fread(buffer, 1, sizeof(buffer), input)) > 0) {
        fwrite(buffer, 1, bytes_read, output);
    }

    fprintf(output, "\n\n");
    fclose(input);
}

void traverse_directory(const char *dir_path, FILE *output) {
    DIR *dir = opendir(dir_path);
    if (!dir) {
        fprintf(stderr, "Warning: Could not open directory: %s\n", dir_path);
        return;
    }

    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        /* Skip hidden files/dirs and . / .. */
        if (entry->d_name[0] == '.')
            continue;

        char full_path[MAX_PATH];
        snprintf(full_path, sizeof(full_path), "%s/%s", dir_path, entry->d_name);

        struct stat st;
        if (stat(full_path, &st) != 0)
            continue;

        if (S_ISDIR(st.st_mode)) {
            traverse_directory(full_path, output);
        } else if (S_ISREG(st.st_mode)) {
            process_file(full_path, output);
        }
    }

    closedir(dir);
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        fprintf(stderr, "Usage: %s <input_folder> <output_file.txt>\n", argv[0]);
        fprintf(stderr, "Example: %s ./my_project output.txt\n", argv[0]);
        return 1;
    }

    const char *input_dir  = argv[1];
    const char *output_path = argv[2];

    /* Verify input is a directory */
    struct stat st;
    if (stat(input_dir, &st) != 0 || !S_ISDIR(st.st_mode)) {
        fprintf(stderr, "Error: '%s' is not a valid directory.\n", input_dir);
        return 1;
    }

    FILE *output = fopen(output_path, "w");
    if (!output) {
        fprintf(stderr, "Error: Could not create output file: %s\n", output_path);
        return 1;
    }

    printf("Scanning '%s'...\n", input_dir);
    traverse_directory(input_dir, output);
    fclose(output);

    printf("Done! All file contents written to '%s'.\n", output_path);
    return 0;
}
