<?php
/**
 * Language Management System
 * Handles loading and switching between English and French
 */

if (!defined('APP_RUNNING')) {
    http_response_code(403);
    exit('Direct access not permitted');
}

/**
 * Load language file
 * 
 * @param string $lang Language code (en or fr)
 * @return array Translation array
 */
function loadLanguage($lang = 'en') {
    $allowed = ['en', 'fr'];
    $lang = in_array($lang, $allowed) ? $lang : 'en';
    
    $file = __DIR__ . '/../lang/' . $lang . '.php';
    
    if (file_exists($file)) {
        return require $file;
    }
    
    // Fallback to English
    return require 'C:\xampp\htdocs\CAMEXAMHUB\includes\lang\fr.php';
}

/**
 * Translate a key
 * 
 * @param string $key Translation key
 * @param string $default Default value if key not found
 * @return string Translated text
 */
function t($key, $default = null) {
    global $translations;
    
    if (isset($translations[$key])) {
        return $translations[$key];
    }
    
    return $default !== null ? $default : $key;
}