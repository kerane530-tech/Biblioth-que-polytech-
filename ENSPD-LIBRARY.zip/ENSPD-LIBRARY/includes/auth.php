<?php
/**
 * ============================================================
 * Authentication & Session Management
 * ============================================================
 * 
 * Handles all user authentication operations:
 * - Session initialization and lifecycle
 * - User login/logout
 * - Registration with validation
 * - Access control checks
 * - CSRF token generation and validation
 * 
 * Security Features:
 * - Password hashing via bcrypt (password_hash/password_verify)
 * - CSRF protection on all forms
 * - Session fixation prevention
 * - Input validation and sanitization
 * ============================================================
 */

// Prevent direct access
if (!defined('APP_RUNNING')) {
    http_response_code(403);
    exit('Direct access not permitted');
}

/**
 * Initialize the session with security settings
 * 
 * Must be called before any session_start() to prevent
 * session fixation attacks.
 */
function initSession(): void {
    // Configure session security settings before starting
    session_name(SESSION_NAME);
    
    // Only send cookie over HTTPS in production
    // (disabled for local XAMPP development)
    // session_set_cookie_params([
    //     'secure'   => true,
    //     'httponly'  => true,
    //     'samesite' => 'Strict',
    // ]);
    
    // Start the session (safe to call multiple times)
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    // Regenerate session ID periodically to prevent fixation
    if (!isset($_SESSION['last_regeneration'])) {
        session_regenerate_id(true);
        $_SESSION['last_regeneration'] = time();
    } elseif (time() - $_SESSION['last_regeneration'] > 300) {
        // Regenerate every 5 minutes
        session_regenerate_id(true);
        $_SESSION['last_regeneration'] = time();
    }
    
    // Check session timeout
    if (isset($_SESSION['last_activity']) && 
        (time() - $_SESSION['last_activity']) > SESSION_TIMEOUT) {
        // Session expired, log the user out
        session_unset();
        session_destroy();
        session_start();
    }
    $_SESSION['last_activity'] = time();
}

/**
 * Check if a user is currently logged in
 * 
 * @return bool True if user has an active session
 */
function isLoggedIn(): bool {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Check if the logged-in user is an admin
 * 
 * @return bool True if current user has admin role
 */
function isAdmin(): bool {
    return isLoggedIn() && ($_SESSION['user_role'] ?? '') === 'admin';
}

/**
 * Get the currently logged-in user's data
 * 
 * Fetches fresh user data from the database to ensure
 * we always have current information.
 * 
 * @return array|null User data array, or null if not logged in
 */
function getCurrentUser(): ?array {
    if (!isLoggedIn()) {
        return null;
    }
    
    return dbFetchOne(
        "SELECT id, username, email, full_name, role, avatar_path, created_at 
         FROM users WHERE id = ? AND is_active = 1",
        [$_SESSION['user_id']]
    );
}

/**
 * Authenticate a user with email and password
 * 
 * Validates credentials against the database, creates a session
 * on success, and returns the result.
 * 
 * @param string $email    User's email address
 * @param string $password Plain-text password to verify
 * @return array           ['success' => bool, 'message' => string, 'user' => array|null]
 */
function loginUser(string $email, string $password): array {
    // Sanitize email input
    $email = filter_var(trim($email), FILTER_SANITIZE_EMAIL);
    
    // Validate email format
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return ['success' => false, 'message' => 'Please enter a valid email address.', 'user' => null];
    }
    
    // Validate password is not empty
    if (empty($password)) {
        return ['success' => false, 'message' => 'Please enter your password.', 'user' => null];
    }
    
    // Look up user by email
    $user = dbFetchOne(
        "SELECT id, username, email, password_hash, full_name, role, is_active 
         FROM users WHERE email = ?",
        [$email]
    );
    
    // Check if user exists and verify password
    if (!$user || !password_verify($password, $user['password_hash'])) {
        // Generic message prevents email enumeration attacks
        return ['success' => false, 'message' => 'Invalid email or password.', 'user' => null];
    }
    
    // Check if account is active
    if (!$user['is_active']) {
        return ['success' => false, 'message' => 'Your account has been disabled. Please contact support.', 'user' => null];
    }
    
    // Regenerate session ID to prevent session fixation
    session_regenerate_id(true);
    
    // Store user data in session
    $_SESSION['user_id']    = $user['id'];
    $_SESSION['username']   = $user['username'];
    $_SESSION['user_role']  = $user['role'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['login_time'] = time();
    
    // Remove sensitive data before returning
    unset($user['password_hash']);
    
    return ['success' => true, 'message' => 'Login successful!', 'user' => $user];
}

/**
 * Register a new user account
 * 
 * Validates all inputs, checks for uniqueness, hashes the password,
 * and creates the account in the database.
 * 
 * @param string $username    Desired username
 * @param string $email       User's email address
 * @param string $password    Plain-text password
 * @param string $confirmPass Password confirmation
 * @param string $fullName    Optional full name
 * @return array              ['success' => bool, 'message' => string]
 */
function registerUser(
    string $username, 
    string $email, 
    string $password, 
    string $confirmPass, 
    string $fullName = ''
): array {
    // Sanitize inputs
    $username  = trim($username);
    $email     = filter_var(trim($email), FILTER_SANITIZE_EMAIL);
    $fullName  = trim($fullName);
    
    // ---- Input Validation ----
    
    // Username validation
    if (strlen($username) < 3) {
        return ['success' => false, 'message' => 'Username must be at least 3 characters long.'];
    }
    if (strlen($username) > MAX_USERNAME_LENGTH) {
        return ['success' => false, 'message' => 'Username must not exceed ' . MAX_USERNAME_LENGTH . ' characters.'];
    }
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
        return ['success' => false, 'message' => 'Username may only contain letters, numbers, and underscores.'];
    }
    
    // Email validation
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return ['success' => false, 'message' => 'Please enter a valid email address.'];
    }
    
    // Password validation
    if (strlen($password) < MIN_PASSWORD_LENGTH) {
        return ['success' => false, 'message' => 'Password must be at least ' . MIN_PASSWORD_LENGTH . ' characters long.'];
    }
    if ($password !== $confirmPass) {
        return ['success' => false, 'message' => 'Passwords do not match.'];
    }
    
    // ---- Duplicate Checks ----
    
    // Check for existing email
    $existing = dbFetchOne("SELECT id FROM users WHERE email = ?", [$email]);
    if ($existing) {
        return ['success' => false, 'message' => 'An account with this email already exists.'];
    }
    
    // Check for existing username
    $existing = dbFetchOne("SELECT id FROM users WHERE username = ?", [$username]);
    if ($existing) {
        return ['success' => false, 'message' => 'This username is already taken.'];
    }
    
    // ---- Create Account ----
    
    // Hash password using bcrypt with default cost
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    
    // Insert new user record
    $stmt = dbQuery(
        "INSERT INTO users (username, email, password_hash, full_name, role, is_active) 
         VALUES (?, ?, ?, ?, 'user', 1)",
        [$username, $email, $passwordHash, $fullName ?: $username]
    );
    
    return ['success' => true, 'message' => 'Account created successfully! You can now log in.'];
}

/**
 * Log the current user out
 * 
 * Destroys all session data and the session cookie,
 * then redirects to the homepage.
 */
function logoutUser(): void {
    // Clear all session variables
    $_SESSION = [];
    
    // Delete the session cookie
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params["path"],
            $params["domain"],
            $params["secure"],
            $params["httponly"]
        );
    }
    
    // Destroy the session on the server
    session_destroy();
    
    // Redirect to homepage
    header('Location: ' . APP_URL . '/index.php');
    exit;
}

/**
 * Generate a CSRF token for form protection
 * 
 * Creates a random token and stores it in the session.
 * Must be called before rendering any form.
 * 
 * @return string The CSRF token to embed in forms
 */
function generateCSRFToken(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Validate a CSRF token from form submission
 * 
 * Compares the submitted token against the session token
 * and clears it after validation (one-time use).
 * 
 * @param string $token Token from form submission
 * @return bool         True if token is valid
 */
function validateCSRFToken(string $token): bool {
    if (empty($_SESSION['csrf_token'])) {
        return false;
    }
    
    // Use hash_equals for timing-safe comparison
    $valid = hash_equals($_SESSION['csrf_token'], $token);
    
    // Clear token after use (one-time use pattern)
    unset($_SESSION['csrf_token']);
    
    return $valid;
}

/**
 * Require the user to be logged in
 * 
 * Redirects to login page if user is not authenticated.
 * Call this at the top of protected pages.
 */
function requireLogin(): void {
    if (!isLoggedIn()) {
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
        header('Location: ' . APP_URL . '/pages/login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
        exit;
    }
}

/**
 * Require the user to be an admin
 * 
 * Shows 403 error if user is not an admin.
 */
function requireAdmin(): void {
    requireLogin();
    if (!isAdmin()) {
        http_response_code(403);
        exit('Access denied. Administrator privileges required.');
    }
}

/**
 * Get the redirect URL after login (if set)
 * 
 * @return string URL to redirect to after login
 */
function getPostLoginRedirect(): string {
    if (isset($_SESSION['redirect_after_login'])) {
        $url = $_SESSION['redirect_after_login'];
        unset($_SESSION['redirect_after_login']);
        return $url;
    }
    return APP_URL . '/index.php';
}
